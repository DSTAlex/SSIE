do  
sudo ./test_module.sh  
It will build, load module, test the module and remove module.


Made by DI SANTO Alexandre