from abc import ABC
from abc import abstractmethod

class Domain(ABC):
    @abstractmethod
    def upperBound(self, s2):
	    pass
	
