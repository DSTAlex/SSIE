from Expression import *
from Program import *
from Domain import *
from Visiteur import *

class DomainSign(Domain):
    def __init__(self, dom):
        self.domain = dom.copy()
        
    def upperBound(self, s2):
        for key in self.domain:
            if key in s2.domain:
                self.domain[key] = self.domain[key].union(s2.domain[key])
        return self.domain
        
    def copy(self):
        return DomainSign(self.domain)
        
    def equals(self, d2):
        return self.domain == d2.domain

class VisiteurSigne(Visiteur):
    def __init__(self, dom):
        self.dom = dom.copy()
        
    def sameVisiteur(self, domain):
        return VisiteurSigne(domain)
        
    def upperBound(self, d1, d2):
        for key in d1:
            if key in d2:
                d1[key] = d1[key].union(d2[key])
        return d1
        
    def visitVar(self, var):
        return self.dom.domain[var.variable]
        
    def visitCst(self, cst):
        if cst.integer == 0:
            return {'0'}
        elif cst.integer < 0:
            return {'-'}
        else:
            return {'+'}

    def visitPlus(self, plus):
        pass

    def visitDiff(self, diff):
        pass
                
    def visitProd(self, prod):
        pass

    def visitDiv(self, div):
        pass

    def visitEq(self, eq):
        pass

    def visitInf(self, inf):
        pass

    def visitNeg(self, neg):
        pass
        
    def visitAffectation(self, affectation):
        self.dom.domain[affectation.variable] = affectation.expression.abstractEvaluation(self)
        return self.dom
        
    def visitIfThenElse(self, ite):
        pass

    def visitWhile(self, whil):
        pass

    def visitPostAssertEq(self, bExp):
        visiteurTest = VisiteurSigne(self.dom)
        for x in self.dom.domain:
            psigns = set()
            for sign in self.dom.domain[x]:
                visiteurTest.dom.domain[x] = {sign}
                if True in bExp.abstractEvaluation(visiteurTest):
                    psigns.add(sign)
            visiteurTest.dom.domain[x] = psigns
        return visiteurTest.dom


    def visitPostAssertInf(self, bExp):
        visiteurTest = VisiteurSigne(self.dom)
        for x in self.dom.domain:
            psigns = set()
            for sign in self.dom.domain[x]:
                visiteurTest.dom.domain[x] = {sign}
                if True in bExp.abstractEvaluation(visiteurTest):
                    psigns.add(sign)
            visiteurTest.dom.domain[x] = psigns
        return visiteurTest.dom


    def visitPostAssertNeg(self, bExp):
        visiteurTest = VisiteurSigne(self.dom)
        for x in self.dom.domain:
            psigns = set()
            for sign in self.dom.domain[x]:
                visiteurTest.dom.domain[x] = {sign}
                if True in bExp.abstractEvaluation(visiteurTest):
                    psigns.add(sign)
            visiteurTest.dom.domain[x] = psigns
        return visiteurTest.dom
