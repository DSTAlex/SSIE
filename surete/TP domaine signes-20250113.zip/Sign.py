import * from Expression
import * from Program
import * from Domain
import * from Visiteur

class DomainSign(Domain):
    def __init__(self, dom):
        self.domain = dom.copy()
        
    def upperBound(self, s2):
    	for key in self.domain:
    	    self.domain[key].union(s2.domain[key])
    	return self.domain

class VisiteurSigne(Visiteur):
    def __init__(self, dom):
        self.dom = dom.cpy()
        
    def visitAffectation(self, affectation):
        self.dom[affectation.variable] = expression.abstractEvaluation(self)
        
    def visitIfThenElse(self, ite):
        pass

        
    def visitWhile(self, whil):
        pass
        
    def visitCst(self, cst):
        if cst.integer = 0:
        	return '0'
        elif cst.integer < 0:
        	return '-'
        else:
        	return '+'
         
    def visitPlus(self, plus):
        pass
        
    def visitDiff(self, diff):
        pass
        
    def visitProd(self, prod):
        pass
        
    def visitDiv(self, div):
	pass
        
    def visitEq(self, eq):
        pass
        
    def visitInf(self, inf):
        pass

    def visitNeg(self, neg):
        pass
        
    def visitPostAssert(self, bExp):
        visiteurTest = VisiteurSigne(self.dom)
        for x in dom:
        	psigns = set()
        	for sign in dom[x]
        		visiteurTest.dom[x] = {sign}
        		if True in bExp.abstractEvaluation(visiteurTest):
        			psigns.add(sign)
        	visiteurTest.dom[x]=psigns
        return visiteurTest.dom
