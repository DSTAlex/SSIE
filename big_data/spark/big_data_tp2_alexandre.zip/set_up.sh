#!/usr/bin/bash

hadoop fs -mkdir -p input
hadoop fs -put input/* input